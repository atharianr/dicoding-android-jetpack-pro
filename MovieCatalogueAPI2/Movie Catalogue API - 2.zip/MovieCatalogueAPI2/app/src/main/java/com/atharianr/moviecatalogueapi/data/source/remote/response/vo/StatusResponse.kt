package com.atharianr.moviecatalogueapi.data.source.remote.response.vo

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}