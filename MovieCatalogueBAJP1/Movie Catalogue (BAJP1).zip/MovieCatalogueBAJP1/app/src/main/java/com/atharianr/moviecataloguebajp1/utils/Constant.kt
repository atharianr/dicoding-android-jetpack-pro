package com.atharianr.moviecataloguebajp1.utils

object Constant {
    const val ID = "id"
    const val TYPE_MOVIE = 0
    const val TYPE_TV_SHOW = 1
}